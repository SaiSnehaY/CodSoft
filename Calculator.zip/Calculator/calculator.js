let result = document.getElementById("result");

function clearScreen() {
    result.value = "";
}

function deleteLast() {
    result.value = result.value.slice(0, -1);
}

function appendNumber(number) {
    result.value += number;
}

function appendOperator(operator) {
    result.value += operator;
}

function appendDot() {
    if (!result.value.includes('.')) {
        result.value += '.';
    }
}

function calculate() {
    try {
        result.value = eval(result.value);
    } catch (e) {
        result.value = "Error";
    }
}
